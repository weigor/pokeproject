package main

import (
	"fmt"
	"strings"
)

//
//type Poke struct {
//	Hands []*List `json:"hands"`
//}
//
//
// func  (poke *Poke)sort() *Poke  {
//	 var result []*List
//	 result := new(Poke)
//	 tmpH := make(map[int][]*Poke)
//
// }re

func main()  {
	var  re= [...]string{"J_1", "4_2","3_1_1"}
	//var sa []int  //nil
 ////sa=make([]int,0)
 //
	//for _,v:=range re{
 //if  len(sa)==0{
	//  sa= append(sa, v)
 //
 //} else{
	//		for k, _ := range sa {
	//			if v>=sa[len(sa)-1]{
	//				sa = append(sa, v)
	//				fmt.Println(sa)
	//				break
	//			} else {
	//				//tmp := pokerJudce.sortPokers
	//				//middle := append([]*Poker{}, tmp[index:]...)
	//				//tmp = append(tmp[:index], poker)
	//				//pokerJudce.sortPokers = append(tmp, middle...)
	//				first:=sa[0:k]
	//				last:=sa[k:]
	//				var t []int
	//				middle := append(t,first...)
	//				//last:=sa[k:]
	//				//var sg []int
	//				first = append(middle, v)
	//				//	tmp=append(tmp,first...)
	//				sa = append(first, last...)
	//				//	break
	//				break
	//			}
	//			//	tmp := sa
 //
	//			}
	//		}
	//  fmt.Println(sa)
 //
 //
	//}
	//var ms map[string]int
	//ms = make(map[string]int)
	//ms["J"]=1
	//ms["K"]=3
	//ms["T"]=2
	//
	//sort.Strings(ms)
	//fmt.Println()
	for _,v:=range re{
		fmt.Println(len(strings.Split(v,"_")))
		//fmt.Println(k,strings.Split(v,"_")[0])
	}

}