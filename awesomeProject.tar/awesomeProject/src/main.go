package main

//
//1.读取文件数据转为对象
//2.循环每组数据对比，调用两次排序，
//3.对每副牌切割，切成单张对应大小和花色存入数组，对该数组循环获取，分别进行匹配，设定默认的牌排序，和花色，通过循环的每个数组每副牌的下标序号对比设定两个变量接收
//4.变量1获取传入的默认每副牌序号，变量2获取排序后的没副牌序号同时可以计算出是否有成对现象，加入变量可以判断每次循环的花色状况，排除同花和同花顺
//5通过循环获取对子数作判断设定等级，对比的牌如果等级相同根据规则牌按顺序排列后最后一位即是最大牌数，同理同花顺和同花色，同花可以根据定义的牌顺序获取同化顺和同花色对应的字符串值返回false即为同化
//设定牌的等级和头衔
//6.将按顺序的按列的牌，每一组获取等级去比较，不相当情况：result==2第一副牌大于第二副  result==1第一副牌小于第二副牌  result==0第一副牌等于第二副牌。
//相等情况：根据排列最后一位获取去比较得出大小
//0.为alice大   2为bob大  1平等
import (
	"awesomeProject/src/method"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

//底基判断牌类型
type Based struct {
	DegreeNum int    `json:"degreeNum"` //判断牌的等级序号
	Degree    string `json:"degree"`    //判断是什么等级的牌
	Desc      string `json:"desc"`      //
}

//每副手牌
type Poker struct {
	face  string
	color string
	card  string //排序后牌大小
	Base  *Based
}

//手牌分析对比
type PokerJudce struct {
	poke        *Poker
	firstPokers []*Poker
	sortPokers  []*Poker
	faceChecked string //保留每副牌的face情况
	whetherTH   bool
	count       int    //统计对子数
	num         int    //最后一位下标
	huLu        bool   //区分三条和葫芦
	lastChar    string //字符去重后结果

}

var facesSort = "23456789TJQKA" //扑克排序

//切割字符串,作为每次一张一张的摸牌
func pokeToString(matches string) *PokerJudce {
	pokerLength := len(matches)
	pokeStr := []string{}
	for i := 0; i < pokerLength/2; i++ {
		pokeStr = append(pokeStr, matches[(i*2):(i+1)*2])
	}
	//matches := new(method.Matches)
	var po *PokerJudce
	po = pokersChange(pokeStr)
	return po
}

//将每次摸牌传入对象调用方法获取排序后的牌，对象接收每张牌信息方便对比
func pokersChange(pokeStr []string) *PokerJudce {
	var pokerJudce *PokerJudce
	if pokerJudce == nil {
		pokerJudce = new(PokerJudce)
	}
	for _, pokerStr := range pokeStr {
		tmpFace := pokerStr[0:1]
		tmpColor := pokerStr[1:2]
		poke := new(Poker)
		poke.face = tmpFace
		poke.color = tmpColor
		if poke == nil {
			return nil
		}
		pokerJudce.pokerSort(poke)
	}
	return pokerJudce
}

//对每张牌进行排序，和牌的等级判断，同时循环获取等级后按照对比大小查看
func (pokerJudce *PokerJudce) pokerSort(poker *Poker) {
	var lastChar string

	if pokerJudce == nil {
		pokerJudce = new(PokerJudce)
	}
	pokerJudce.firstPokers = append(pokerJudce.firstPokers, poker) //初始的牌放入
	//fmt.Println("进来了")
	//var count int
	if pokerJudce != nil && len(pokerJudce.sortPokers) > 0 {
		//	fmt.Println("进来了2")
		joinedPoker := false
		for index, p := range pokerJudce.sortPokers {

			if poker.checkPoker(p) {
				joinedPoker = true
				tmp := pokerJudce.sortPokers
				middle := append([]*Poker{}, tmp[index:]...)
				tmp = append(tmp[:index], poker)
				pokerJudce.sortPokers = append(tmp, middle...)
				break
			}
		}
		// 直接插入数组最后一位
		if !joinedPoker {
			pokerJudce.sortPokers = append(pokerJudce.sortPokers, poker)

		}
	} else {
		pokerJudce.sortPokers = append(pokerJudce.sortPokers, poker)

	}

	//判断同花情况和包含牌情况将每张牌与第一次放入的数组逐个匹配
	if poker.color != pokerJudce.firstPokers[0].color {
		pokerJudce.whetherTH = true
	}
	//只获取牌的牌面值后面通过牌面值对比定义的牌大小下标
	if pokerJudce != nil && len(pokerJudce.sortPokers) == 5 {
		for i := 0; i < len(pokerJudce.sortPokers); i++ {
			pokerJudce.faceChecked += string(pokerJudce.sortPokers[i].face)
		}
		//判断该牌是否是葫芦作区分
		var first bool
		first = pokerJudce.faceChecked[0] == pokerJudce.faceChecked[1]
		var second bool
		second = pokerJudce.faceChecked[2] == pokerJudce.faceChecked[3]
		var third bool
		third = pokerJudce.faceChecked[3] == pokerJudce.faceChecked[4]

		var one bool
		first = pokerJudce.faceChecked[0] == pokerJudce.faceChecked[1]
		var two bool
		second = pokerJudce.faceChecked[1] == pokerJudce.faceChecked[2]
		var three bool
		third = pokerJudce.faceChecked[3] == pokerJudce.faceChecked[4]

		if first && second && third || one && two && three {
			pokerJudce.huLu = true
		}
		//获取最后一次不重复字符串出现的下标
		var num int = 0 //统计个数
		var ms map[string]int
		ms = make(map[string]int) //通过map的不重复获取手牌的每张数目大小
		var result string         // 存放结果 //作为判断的值因为序号已经排好序这里是作去重
		var re []int
		var rs []string
		//数组排好序后，每次循环判断Num的值不重复的num==1即为自己
		for j := range pokerJudce.faceChecked {
			num = 0

			for d := range pokerJudce.faceChecked {

				if pokerJudce.faceChecked[j] == pokerJudce.faceChecked[d] {

					num = num + 1
				}
			}
			ms[string(pokerJudce.faceChecked[j])] = num
			if strings.Contains(result, string(pokerJudce.faceChecked[j])) == false {
				result += string(pokerJudce.faceChecked[j])
				re = append(re, num)
				rs = append(rs, string(pokerJudce.faceChecked[j])+"_"+strconv.Itoa(num))
			}

		}

		//以下三段代码通过每张牌数目提添加进入数组，在通过自己按照自己定义先按照什么对比，在转为对应的字符串，main方法中通过获取该不重复字符串循环对比，有优化点这段查询：主要map无序
		//对牌进行去重处理获取对应的牌数目数组re为排序好但是没有按value大小排序sa为排序好的
		var sa []int //nil
		for _, v := range re {
			if len(sa) == 0 {
				sa = append(sa, v)

			} else {
				for k, _ := range rs {
					if v >= sa[len(sa)-1] {
						sa = append(sa, v)
						fmt.Println(sa)
						break
					} else {
						first := sa[0:k]
						last := sa[k:]
						var t []int
						middle := append(t, first...)
						//last:=sa[k:]
						//var sg []int
						first = append(middle, v)
						//	tmp=append(tmp,first...)
						sa = append(first, last...)
						//	break
						break
					}
					//	tmp := sa

				}
			}

		}
		//通过排序好的每副牌获取对应的数目，对比存入的字符串数组，获取最终的不重复str

		for _, v := range sa {
			for k, s := range rs {
				int, _ := strconv.Atoi(strings.Split(s, "_")[1])
				if v == int && len(strings.Split(s, "_")) != 3 {
					lastChar += strings.Split(s, "_")[0]
					rs[k] = strings.Split(s, "_")[0] + "_" + strings.Split(s, "_")[1] + "_" + "1"
					break
				}
			}
		}

		pokerJudce.lastChar = lastChar
		//排序例如777KK先按照7在按照k排序
		var s []int
		for _, v := range re {
			for _, t := range s {
				if v >= t {
					s = append(s, v)
				} else {
					tmp := s
					var sg []int
					sg = append(sg, v)
					sg = append(sg, tmp...)
					break
				}
			}
		}
		//	pokerJudce.distinct=result

		//判断牌的类型等级通过map存储的总出现值判断
		var temp int
		if len(ms) == 5 {

			pokerJudce.count = 0
		} else if len(ms) == 4 {
			pokerJudce.count = 1
		} else if len(ms) == 3 {
			for _, v := range ms {
				if v == 3 {
					temp = 3

				} else {
					temp = 2
				}
			}
			pokerJudce.count = temp
		} else if len(ms) == 2 {
			if pokerJudce.huLu {
				pokerJudce.count = 3
			} else {
				pokerJudce.count = 4
			}
		}

	}

}

//比较当前牌和已经排序好的数组对比
func (poker *Poker) checkPoker(pokerName *Poker) bool {
	if strings.Index(facesSort, poker.face) < strings.Index(facesSort, pokerName.face) {
		return true
	} else {
		return false
	}
}

func main() {
	t1:=time.Now()
	s := method.List{}
	s = method.Data()
	temp := "TJQKA"
	shunZi := "2345A"
	for k, v := range s.Matches {
		var bob *PokerJudce
		bob = new(PokerJudce)
		bob = pokeToString(v.Bob)
		var st *Poker
		st = new(Poker)
		bob.poke = st
		var ba *Based
		ba = new(Based)
		bob.poke.Base = ba
		if !bob.whetherTH { //判断同花
			if strings.Contains(temp, bob.faceChecked) {
				//插入等级和返回值
				bob.poke.Base.DegreeNum = 1
				bob.poke.Base.Degree = "皇家同花顺"
			} else if strings.Contains(shunZi, bob.faceChecked) || strings.Contains(facesSort, bob.faceChecked) {
				//同花顺
				bob.poke.Base.DegreeNum = 2
				bob.poke.Base.Degree = "同花顺"

			} else {
				//同花插入
				bob.poke.Base.DegreeNum = 5
				bob.poke.Base.Degree = "同花"

			}

		} else {
			//判断顺子
			if strings.Contains(facesSort, bob.faceChecked) {
				//同花顺
				bob.poke.Base.DegreeNum = 2
				bob.poke.Base.Degree = "顺子"

			} else {
				//判断对子数目

				switch bob.count {

				case 0:

					bob.poke.Base.DegreeNum = 10
					//poker.Base.Degree="单张"
					//bob.poke=poker
					bob.poke.Base.Degree = "单张"
					break
				case 1:
					bob.poke.Base.DegreeNum = 9
					bob.poke.Base.Degree = "一对"
					break
				case 2:
					bob.poke.Base.DegreeNum = 8
					bob.poke.Base.Degree = "两对"
					break
				case 3:
					if bob.huLu {
						bob.poke.Base.DegreeNum = 4
						bob.poke.Base.Degree = "葫芦"
						break
					} else {
						bob.poke.Base.DegreeNum = 7
						bob.poke.Base.Degree = "三条"
						break
					}
				case 4:
					bob.poke.Base.DegreeNum = 6
					bob.poke.Base.Degree = "四条"
					break
				}

			}

		}
		var alice *PokerJudce
		alice = new(PokerJudce)
		alice = pokeToString(v.Alice)
		var sts *Poker
		sts = new(Poker)
		alice.poke = sts
		var bas *Based
		bas = new(Based)
		alice.poke.Base = bas
		if !alice.whetherTH { //判断同花
			if strings.Contains(temp, alice.faceChecked) {
				//插入等级和返回值
				alice.poke.Base.DegreeNum = 1
				alice.poke.Base.Degree = "皇家同花顺"
			} else if strings.Contains(shunZi, alice.faceChecked) || strings.Contains(facesSort, alice.faceChecked) {
				//同花顺
				alice.poke.Base.DegreeNum = 2
				alice.poke.Base.Degree = "同花顺"

			} else {
				//同花插入
				alice.poke.Base.DegreeNum = 5
				alice.poke.Base.Degree = "同花"

			}

		} else {
			//判断顺子
			if strings.Contains(facesSort, alice.faceChecked) {
				//同花顺
				alice.poke.Base.DegreeNum = 2
				alice.poke.Base.Degree = "顺子"

			} else {
				//判断对子数目
				switch alice.count {
				case 0:
					alice.poke.Base.DegreeNum = 10
					alice.poke.Base.Degree = "单张"
				case 1:
					alice.poke.Base.DegreeNum = 9
					alice.poke.Base.Degree = "一对"
				case 2:
					alice.poke.Base.DegreeNum = 8
					alice.poke.Base.Degree = "两对"
				case 3:
					if alice.huLu {
						alice.poke.Base.DegreeNum = 4
						alice.poke.Base.Degree = "葫芦"
					} else {
						alice.poke.Base.DegreeNum = 7
						alice.poke.Base.Degree = "三条"
					}
				case 4:
					alice.poke.Base.DegreeNum = 6
					alice.poke.Base.Degree = "四条"
				}

			}

		}

		if bob.poke.Base.DegreeNum == alice.poke.Base.DegreeNum {
			//多种情况判断

			//判断每一组中前者牌和后者牌的大小改变result
			for i := len(bob.lastChar) - 1; i >= 0; i-- {
				for j := len(alice.lastChar) - 1; j >= 0; j-- {
					var a = strings.Index(facesSort, string(bob.lastChar[i]))
					var b = strings.Index(facesSort, string(alice.lastChar[i]))

					if a == b {
						break
					} else if a != b && bob.num == 0 && alice.num == 0 {
						bob.num = a
						alice.num = b
						break
					}
				}
			}
			//第一种皇家同花顺
			if bob.poke.Base.DegreeNum == 1 && alice.poke.Base.DegreeNum == 1 {
				s.Matches[k].Result = 1
			} else if bob.num == alice.num {

				s.Matches[k].Result = 1
			} else if bob.num > alice.num {
				s.Matches[k].Result = 2
			} else if bob.num < alice.num {
				s.Matches[k].Result = 0
			}

		} else if bob.poke.Base.DegreeNum > alice.poke.Base.DegreeNum {
			s.Matches[k].Result = 0
		} else if bob.poke.Base.DegreeNum < alice.poke.Base.DegreeNum {
			s.Matches[k].Result = 2
		}

	}
	//创建或者打开文件
	file, e := os.Create("./temp.txt")
	if e != nil {
		fmt.Println("创建文件失败！", e)
	}
	//生成文件编码器
	encoder := json.NewEncoder(file)
	//使用编码器将结构体编码到文件中
	encode := encoder.Encode(s.Matches)
	if encode != nil {
		fmt.Println("写入文件失败！")
	}
	file.Close()

	//打开文件
	open, i := os.Open("./temp.txt")
	if i != nil {
		fmt.Println("文件打开失败！")
	}
	//代码执行最后将文件关闭
	defer open.Close()

	//生成文件解码器
	decoder := json.NewDecoder(open)
	decode := decoder.Decode(&s.Matches)
	if decode != nil {
		fmt.Println("文件反序列化失败！")
	}
	fmt.Println("完成")
t2:=time.Now()
fmt.Println(t2.Sub(t1))
}
