package method

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"time"
)

type Matches struct {
	Alice  string `json:"alice"`
	Bob    string `json:"bob"`
	Result int    `json:"result"`
}

type List struct {
	Matches []Matches `json:"matches"`
}

func Data() List {
	var ki List
t1:=time.Now()
	inputFile, inputError := os.Open("/usr/local/match.json")
	if inputError != nil {
		return ki
	}
	defer inputFile.Close()

	//按行读取文件
	var s string
	inputReader := bufio.NewReader(inputFile)
	for {
		inputString, readerError := inputReader.ReadString('\n')
		if readerError == io.EOF {
			break
		}
		s = s + inputString
	}

	json.Unmarshal([]byte(s), &ki) //将序列化的byte[]重写反序列化为对象。
	//fmt.Println(b)//打印序列化的byte[]
	//fmt.Println(ki) //打印对象的信息
	//for _, v := range ki.Matches {
	//	fmt.Println(v.Bob, v.Alice)
	t2:=time.Now()
	fmt.Println(t2.Sub(t1))
	//}
	return ki
}
